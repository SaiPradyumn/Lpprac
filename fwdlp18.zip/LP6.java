import java.io.*;
import java.util.*;
public class sdts {
    static int count=1,temp=1;
    static Stack<Integer> stack=new Stack<Integer>();
    static ArrayList<String> arr=new ArrayList<String>();
    static HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
    public static void main(String[] args) throws IOException{
        String read="";
        BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Admin\\Desktop\\input.txt"));
        while((read=br.readLine())!=null){
            if(read.startsWith("{")==false)
                generator(read);
            
            
        }
        for(String s:arr){
            if(s.contains("X")){
                int y=map.get(Integer.parseInt(String.valueOf(s.charAt(0))));
                s.replace('X', String.valueOf(y).charAt(0));
                System.out.println(s.substring(0,7)+""+y);
            }
            else
                System.out.println(s);
        }
        System.out.println(arr);
        
    }
    
    public static void generator(String s){
        if(s.startsWith("for")){
            String[] split=s.split(";");
            split[0]=split[0].substring(4);
            System.out.println(count+"."+split[0]);
            arr.add(String.valueOf(count+"."+split[0]));
            count++;
            System.out.println(count+"."+"if("+split[1]+")"+"goto"+(count+5));
            arr.add(String.valueOf(count+"."+"if("+split[1]+")"+"goto"+(count+5)));
            count++;
            System.out.println(count+"."+"goto X");
            arr.add(String.valueOf(count+"."+"goto X"));
            stack.push(count);
            count++;
            split[2]=split[2].substring(0,4);
            
            System.out.println(count+".t"+temp+"="+String.valueOf(split[2].charAt(0))+String.valueOf(split[2].charAt(1))+"1");
            arr.add(String.valueOf(count+".t"+temp+"="+String.valueOf(split[2].charAt(0))+String.valueOf(split[2].charAt(1))+"1"));
            count++;
            System.out.println(count+"."+String.valueOf(split[2].charAt(0))+"=t"+temp);
            arr.add(String.valueOf(count+"."+String.valueOf(split[2].charAt(0))+"=t"+temp));
            
            count++;
            temp++;
            
            System.out.println(count+"."+"goto 2");
            arr.add(String.valueOf(count+"."+"goto 2"));
            count++;
        }
        
        else if(s.startsWith("if")){
            System.out.println(count+"."+s+""+"goto"+(count+2));
            arr.add(String.valueOf(count+"."+s+""+"goto"+(count+2)));
            count++;
            System.out.println(count+".goto X");
            arr.add(String.valueOf(count+".goto X"));
            stack.push(count);
            count++;
            
            
        }
        else if(s.startsWith("else")){
            int x=stack.pop();
            map.put(x, count);
        }
        else if(s.startsWith("}")){
            int x=stack.pop();
            map.put(x,count+1);
            System.out.println(count+"."+"goto"+(x+1));
            arr.add(String.valueOf(count+"."+"goto"+(x+1)));
            count++;
            
        }
        else
        {
            System.out.println(count+".t"+temp+"="+s.substring(2,5));
            arr.add(String.valueOf(count+".t"+temp+"="+s.substring(2,5)));
            count++;
            System.out.println(count+"."+String.valueOf(s.charAt(0))+"=t"+temp);
            arr.add(String.valueOf(count+"."+String.valueOf(s.charAt(0))+"=t"+temp));
            count++;
            temp++;
        }
    }
}
/*
input.txt
for(i=1;i<=20;i++)
{
if(a<b)then
x=y+z
else
p=q+r
}
output
1.i=1
2.if(i<=20)goto7
3.goto X
4.t1=i+1
5.i=t1
6.goto 2
7.if(a<b)thengoto9
8.goto X
9.t2=y+z
10.x=t2
11.t3=q+r
12.p=t3
13.goto4
1.i=1
2.if(i<=20)goto7
3.goto 14
4.t1=i+1
5.i=t1
6.goto 2
7.if(a<b)thengoto9
8.goto 11
9.t2=y+z
10.x=t2
11.t3=q+r
12.p=t3
13.goto4
*/
